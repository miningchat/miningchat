# MiningDataOnline Platform
MiningDataOnline is an initiative to build a simple to use platform intended for individuals without programming knowledge to build customizable web data warehouses designed to incentivize collection and sharing of structured data in exchange for micro payments.
