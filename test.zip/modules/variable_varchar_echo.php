<?php
				if (trim($variable_2_value) == trim($variable_1_value) && $variable_1_activate_value==2 && $variable_2_activate_value==2) {
				$variable_echo = $variable_1_value;					
				} else if ($variable_1_activate_value==3) {
				$variable_echo = $variable_1_value;					
				} else if ($variable_2_activate_value==3) {
				$variable_echo = $variable_2_value;					
				} 
?>