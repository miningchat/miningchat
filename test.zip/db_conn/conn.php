<?php
//Database Host
$db_host = 'localhost';
//Database Name
$db_database = 'miningprojects';
//Database Username
$db_user = 'miningdataonline';
//Database Password
$db_pass = 'ihC7l0?1';
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_database);
?>
